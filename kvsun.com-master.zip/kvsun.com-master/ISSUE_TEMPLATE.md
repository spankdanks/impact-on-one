### Steps to reproduce
1.  
2.  
3.  

### Expected behavior
Tell us what should have happened

### Actual behavior
Tell us what happened instead

### Screenshots and/or logs (see how to open the developer console in your browser)
Drag and drop file to upload and include in bug report
